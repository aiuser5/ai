# Artificial-Intelligence-Lab-Assignments
1) 8-Puzzle using AStar

2) 8-Puzzle using Hill Climbing

3) Single Layer Preceptron Traning

4) Fuzzy Set

5) Tiny Expert System in Prolog

6) Tic Tac toe using Minmax


